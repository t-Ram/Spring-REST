package com.annathe.training.springrest2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRest2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringRest2Application.class, args);
	}

}
