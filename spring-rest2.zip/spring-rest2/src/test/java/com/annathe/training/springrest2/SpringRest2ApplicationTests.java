package com.annathe.training.springrest2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRest2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
