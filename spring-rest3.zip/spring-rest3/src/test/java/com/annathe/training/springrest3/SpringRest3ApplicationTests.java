package com.annathe.training.springrest3;

import static org.junit.jupiter.api.Assertions.assertNotNull;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get; 
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status; 
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath; 
 
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc; 
import org.springframework.test.web.servlet.MockMvc; 
import org.springframework.test.web.servlet.ResultActions; 


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.annathe.training.springrest3.controller.EmployeeController;

@SpringBootTest
@AutoConfigureMockMvc 
class SpringRest3ApplicationTests {
	
	@Autowired 
	private EmployeeController employeeController; 

	@Autowired 
	private MockMvc mvc; 


	@Test
	void contextLoads() {
		
		assertNotNull(employeeController); 
	}

	
	
	/*
	 * @Test public void testGetEmployee() throws Exception {
	 * 
	 * ResultActions actions = mvc.perform(get("/employees/2"));
	 * actions.andExpect(status().isOk());
	 * actions.andExpect(jsonPath("$.name").exists());
	 * actions.andExpect(jsonPath("$.name").value("Krishna"));
	 * 
	 * }
	 */
	 
	 
	
	  @Test 
	  public void testGetEmployeeException() throws Exception {
		  ResultActions actions = mvc.perform(get("/employees/5"));
	  actions.andExpect(status().isNotFound());
	  
	  
	  }
	 
	 
}
