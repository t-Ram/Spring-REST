package com.annathe.training.springrest1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.slf4j.Logger; 

import org.slf4j.LoggerFactory; 

import com.annathe.training.springrest1.model.Employee;

@SpringBootApplication
public class SpringRest1Application {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SpringRest1Application.class); 

	public static void main(String[] args) {
		SpringApplication.run(SpringRest1Application.class, args);
		
		//displayEmployee();
		displayEmployeeList();
	}

	
	public static void displayEmployee() {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml"); 
		Employee employee = (Employee) context.getBean("employee", Employee.class); 
		
		System.out.println("Employee id: "+employee.getId());
		System.out.println("Employee name: "+employee.getName());
	}


public static void displayEmployeeList() {
	 	LOGGER.info("START");
		
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml"); 
		List employeeList = (ArrayList) context.getBean("employeeList"); 
		
		Iterator itr = employeeList.iterator();
		
		while(itr.hasNext()) {
			
			Employee employee = (Employee)itr.next();
			LOGGER.debug(employee.getName());
			
		System.out.println("Employee id: "+employee.getId());
		System.out.println("Employee name: "+employee.getName());
		
		}
		LOGGER.info("END");
	}





}
